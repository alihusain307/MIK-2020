<?php 
include 'config/koneksi 2.php';

$id= $_GET['id'];

$sql = "DELETE FROM nilai_akhir WHERE id= '$id'";

if (mysqli_query($koneksi, $sql)) {
  echo "Record deleted successfully";
  header('Location: nilai akhir.php');
} else {
  echo "Error deleting record: " . mysqli_error($koneksi);
}

 ?>