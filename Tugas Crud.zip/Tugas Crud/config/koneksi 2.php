<?php 
 $koneksi = mysqli_connect("localhost", "root", "", "crud_alihusain");

 ?>