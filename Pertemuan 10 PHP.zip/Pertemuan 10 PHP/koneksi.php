<?php 
$server= 'localhost';
$user= 'root';
$password= '';
$database= 'db_phpdasar';

$koneksi= mysqli_connect($server, $user, $password, $database);
 ?>