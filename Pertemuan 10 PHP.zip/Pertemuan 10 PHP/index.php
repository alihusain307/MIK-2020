  <!DOCTYPE html>
  <html>
  <head>
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="assets/css/materialize.min.css"  media="screen,projection"/>

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>

  <body>
    <div class="container">
      <div class="row">
        <div class="col s12 m12">
          <div class="card" style="margin: 100px 350px 0px 350px">
            <div class="card-content">
              <h3 class="center">LOGIN</h3>
              <form action="" method="POST">
                <div class="row">
                  <div class="input-field col s12">
                   <input placeholder="Masukan Username" id="usr" type="text" class="validate" name="user">
                   <label for="usr">Username</label>
                 </div>
                 <div class="input-field col s12">
                   <input placeholder="Masukkan Password" id="pw" type="password" class="validate" name="pass">
                   <label for="pw">Password</label>
                 </div>
                 <div class="input-field col s6">
                   <input class="btn-small blue accent-3" name="login" type="submit" value="Login">
                 </div>
                 <div class="input-field col s6">
                   <a href="daftar.php"class="btn-small blue accent-3 right">Registrasi</a>
                 </div>
               </div>
             </form>
             <?php 
             session_start();
             include'koneksi.php';

             if (isset($_POST['login'])) {
              $usr=$_POST['user'];
              $pwd=($_POST['pass']);
              var_dump($usr, $pwd);

              $sql = mysqli_query($koneksi, "SELECT * FROM login WHERE username ='$usr' AND password = '$pwd'");

              $data = mysqli_fetch_array($sql);
              $username = $data['username'];
              $password = $data['password'];
              $level = $data['level'];

              if ($usr == $username && $pwd == $password) {
                $_SESSION['level'] =='admin';
                header('location: dashboard.php');

              } if ($_SESSION['level'] == 'user') {
                header('location: biodata.php');
              } else {
                header('location: login.php');
              }
            }
            ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!--JavaScript at end of body for optimized loading-->
  <script type="text/javascript" src="assets/js/materialize.min.js"></script>
</body>
</html>