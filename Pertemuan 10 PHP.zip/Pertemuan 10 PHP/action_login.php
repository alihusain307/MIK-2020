<?php 
session_start();
include'koneksi.php';

 if ($_POST['submit']) {
    $usr=$_POST['username'];
  $pwd=($_POST['password']);
var_dump($usr, $pwd);

  $sql = mysqli_query($koneksi, "SELECT * FROM login WHERE username ='$usr' AND password = '$pwd'");

  $data = mysqli_fetch_array($sql);
 $username = $r['username'];
 $password = $r['password'];
 $level = $r['level'];
 if ($usr == $username && $pwd == $password) {
  $_SESSION['level'] = 'admin';
  header('location: dashboard.php');

 // } if ($_SESSION['level'] = 'user') {
 //      header('location : index.php');
 } else {
    header('location: login.php');
 }
 }





//   if (mysqli_num_rows($sql)=== 1) {

//     $row = mysqli_fetch_assoc($sql);

//     if (password_verify($pwd, $row['password'])) {

//         session_start();

//         $_SESSION['password'] = true;
//         header('location: dashboard.php');
//         exit;
//   } else {
//     echo "<script>alert('Username yang di masukan salah!')</script>";
//   }
// }
?>