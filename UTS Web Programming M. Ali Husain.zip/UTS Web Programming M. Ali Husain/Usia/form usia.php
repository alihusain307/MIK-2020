
 <!DOCTYPE html>
 <html lang="en">
 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Usia</title>
 </head>
 <body>
     <form action="program form.php" method="POST" >
        <label>Nama:</label>
        <input type="text" name="nama"><br>
                <label>Usia:</label>
        <input type="text" name="usia"><br>
        <button type="submit" name="submit">Submit</button>
    </form>
 </body>
 </html>