 <!DOCTYPE html>
 <html lang="en">
 <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Penghitungan Gaji</title>
 </head>
 <body>
     <form action="program form.php" method="POST" >
        <label>Nama:</label>
        <input type="text" name="nama"><br>
                <label>Jam Kerja:</label>
        <input type="text" name="jam_kerja"><br>
                <label>Golongan:</label>
        <input type="text" name="golongan"><br>
        <button type="submit" name="submit">Submit</button>
    </form>
 </body>
 </html>

 

