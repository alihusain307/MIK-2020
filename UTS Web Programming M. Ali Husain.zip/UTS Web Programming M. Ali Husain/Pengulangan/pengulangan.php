<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <table>
        <tr>            
            <td>
                Anak ayam turun 10
                <?php 
                $z=10;
                $i=10;
                do {
                 echo "<br>Anak ayam turun".$z", mati satu tunggal".$i;
                 $z++;
                 $i++;
                }
                 while ($z <= 10);
                 while ($i <= 10);
                ?>

            </td>
        </tr>
    </table>
    
</body>
</html>
<!-- <?php 
// do.while ( <= 10) {
    # code...
 ?> -->