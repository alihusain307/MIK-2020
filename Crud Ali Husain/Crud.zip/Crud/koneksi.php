<?php  
$server = 'localhost';
$user = 'root';
$password = '';
$database = 'db_dts_2020';

$koneksi = mysqli_connect($server, $user, $password, $database);

?>