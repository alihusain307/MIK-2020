<?php 
include'koneksi.php';

  $usr=$_POST['username'];
  $pwd=($_POST['password']);
// var_dump($usr, $pwd);

  $sql = mysqli_query($koneksi, "SELECT * FROM login WHERE username ='$usr'");

  if (mysqli_num_rows($sql)=== 1) {

    $row = mysqli_fetch_assoc($sql);

    if (password_verify($pwd, $row['password'])) {

        session_start();

        $_SESSION['password'] = true;
        header('location: dashboard.php');
        exit;
  } else {
    echo "<script>alert('Username yang di masukan salah!')</script>";
  }
}
?>